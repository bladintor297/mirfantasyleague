<!-- Back to top button -->
<a href="#top" class="btn-scroll-top" data-scroll>
    <span class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span>
    <i class="btn-scroll-top-icon bx bx-chevron-up"></i>
</a><?php /**PATH C:\Users\user\Desktop\mlbb\resources\views/inc/top-button.blade.php ENDPATH**/ ?>