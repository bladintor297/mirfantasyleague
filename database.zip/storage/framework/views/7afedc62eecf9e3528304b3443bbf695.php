<?php $__env->startSection('content'); ?>
    
    

    <!-- Hero -->
    <section class="dark-mode hero bg-size-cover bg-repeat-0 bg-position-center position-relative overflow-hidden pb-5 ">
        <div class="container position-relative zindex-2 pb-md-2 pb-lg-4  hero-container ">

            <!-- Title -->
            <div class="row d-flex justify-content-center text-center pb-4 mb-2 zindex-5">
                <div class="col">
                    <h2 class="display-2 mb-4 text-warning">All Leagues</h2>
                </div>
            </div>

            <!-- Dark bordered table -->
            <div class="table-responsive">
                <table class="table table-dark table-bordered">
                    <thead>
                        <tr>
                        <th scope="col">#TeamID</th>
                        <th scope="col" width="10%">Group</th>
                        <th scope="col">Team Name</th>
                        <th scope="col">Team Logo</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                        
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form action="<?php echo e(route('team.update', ['team' => $team->id])); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <tr>
                                    <th scope="row"><?php echo e($team->id); ?></th>
                                    <td>
                                        <select name="label" class="form-select" id="label">
                                            <?php for($i = 'A'; $i <= 'D'; ++$i): ?>
                                                <option value="<?php echo e($i); ?>" <?php echo e($i == $team->label ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </td>
                                    <td><?php echo e($team->team_name); ?></td>
                                    <td><img src="<?php echo e($team->logo); ?>" alt="" style="height: 30px"> </td>
                                    <td >
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" role="switch" id="status" name="status" <?php echo e($team->status ? 'checked' : ''); ?>>
                                        </div>
                                    </td>
                                    <td>
                                        <button type="submit" class="btn btn-warning btn-sm">Update</button>
                                    </td>
                                </tr>
                            </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\mlbb\resources\views/league/manage-team.blade.php ENDPATH**/ ?>