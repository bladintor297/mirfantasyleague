<?php $__env->startSection('content'); ?>
<!-- Hero image -->
<div class="jarallax d-none d-md-block" data-jarallax data-speed="0.35" style="position: relative;">
    <span class="position-absolute top-0 start-0 w-100 h-100 "></span>
    <div class="jarallax-img"
        style="background-image: url('<?php echo e(asset('assets/img/league/header-wildcard.png')); ?>'); background-size: cover;">
    </div>
    <div class="d-none d-xxl-block" style="height: 500px;"></div>
    <div class="d-none d-md-block d-xxl-none" style="height: 550px;"></div>
</div>

<!-- Hero -->
<section
    class="dark-mode bg-dark hero bg-size-cover bg-repeat-0 bg-position-center position-relative overflow-hidden pb-5 ">
    <div class="container position-relative zindex-2 pb-md-2 pb-lg-4  hero-container ">

        <!-- Title -->
        <div class="row d-flex justify-content-center text-center pb-4 mb-2 zindex-5">
            <div class="col">
                <h2 class="display-5 mb-4 text-warning">M5 World Championship</h2>
            </div>
        </div>

        <!-- Icon boxes (Features) -->
        <div class="row row-cols-1 row-cols-md-3 g-4 pt-2 pt-md-4 pb-lg-2 d-flex justify-content-center">

            <div class="row g-3 card shadow w-75 py-4 px-5 overflow-auto row-submission" style="height:500px">

                <?php $count = 0 ?>
                
                <!-- Step 5: Form Submission -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <?php
                        $roles = [
                            'EXP_Laner',
                            'Jungler',
                            'Mid_Laner',
                            'Gold_Laner',
                            'Roamer',
                        ];
                        $reserveRoles = [
                            'Reserve_1',
                            'Reserve_2',
                            'Reserve_3',
                            'Reserve_4',
                            'Reserve_5',
                        ];
                    ?>
                    <form action="<?php echo e(route('myTeam.update', ['myTeam' => 4])); ?>" method="post" id="selectHeroForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="col">
                            <p class="h4 text-center text-uppercase text-white" align="justify">
                                - Confirm Your Players -
                            </p>
                        </div>
                        <div class="col-12 mb-5 mb-lg-3">
                            <div class="table-responsive">
                                <table class="table table-dark table-bordered table-submission">
                                    <thead>
                                        <tr>
                                        <th scope="col">#PlayerID</th>
                                        <th scope="col">Roles</th>
                                        <th scope="col">Player Name</th>
                                        <th scope="col">Team</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleKey => $roleValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th scope="row" class="text-center">
                                                        <div class="d-flex justify-content-center">
                                                            <?php echo e($myTeam->{$roleValue}); ?> 
                                                            <?php if($myTeam->captain == $myTeam->{$roleValue} ): ?>
                                                                <i class='bx bx-crown text-warning my-auto ms-1' style="font-size: 1.5rem"></i>
                                                            <?php endif; ?>

                                                            <?php if($myTeam->vice_captain == $myTeam->{$roleValue} ): ?>
                                                                <i class='bx bx-crown text-warning my-auto ms-1' style="font-size: 1.0rem"></i>
                                                            <?php endif; ?>
                                                        </div>
                                                    </th>
                                                    <td>
                                                        <?php echo e($roles[$roleKey]); ?>

                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($player->id == $myTeam->{$roleValue}): ?>
                                                                <?php echo e($player->name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($player->id == $myTeam->{$roleValue}): ?>
                                                                <?php echo e($player->team_name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php if($game->reserve_isOn == 1): ?>
                                                <?php $rsvcnt= 0;?>
                                                <?php $__currentLoopData = $reserveRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleKey => $roleValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($myTeam->{'Reserve_'.$roleKey+1} !== null): ?>
                                                    <tr>
                                                        <th scope="row" class="text-center">
                                                            <?php echo e($myTeam->{'Reserve_' . $roleKey +1}); ?>

                                                        </th>
                                                        <td>
                                                            <input type="text" value="<?php echo e($reserveRoles[$roleKey]); ?> -- (<?php echo e($roles[$roleKey]); ?>)" class="form-control"  id="" readonly>
                                                        </td>
                                                        <td>
                                                            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($player->id == $myTeam->{'Reserve_' . $roleKey +1}): ?>
                                                                    <input type="text" value="<?php echo e($player->name); ?>" class="form-control"  id="" readonly>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            
                                                        </td>
                                                        <td>
                                                            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($player->id == $myTeam->{'Reserve_' . $roleKey +1}): ?>
                                                                    <input type="text" name="teamNames[]" value="<?php echo e($player->team_name); ?>" class="form-control" readonly/>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col d-flex justify-content-between mt-5 pb-3 py-2">
                            <input type="hidden" value="<?php echo e($game->id); ?>" name="game_id">
                            <input type="hidden" value="<?php echo e($myTeam->id); ?>" name="myTeam_id">
                            <a href="/league/<?php echo e($game->id); ?>" class="btn btn-warning mx-1">Back</a>
                            <button type="submit" class="btn btn-success mx-1">Register</button>
    
                        </div>

                    </form>
                    
                    
                </div>


                
                
            </div>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\mlbb\resources\views/league/team-submission.blade.php ENDPATH**/ ?>