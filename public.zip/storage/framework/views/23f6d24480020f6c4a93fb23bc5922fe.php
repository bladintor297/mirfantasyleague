<?php $__env->startSection('content'); ?>
    
    <!-- Hero image -->
    <div class="jarallax d-none d-md-block" data-jarallax data-speed="0.35" style="position: relative;">
        <span class="position-absolute top-0 start-0 w-100 h-100 "></span>
        <div class="jarallax-img"
            style="background-image: url(assets/img/league/header-zilong.png); width: 100%; background-size: cover;">
        </div>
        <div class="d-none d-xxl-block" style="height: 450px;"></div>
        <div class="d-none d-md-block d-xxl-none" style="height: 550px;"></div>
    </div>

    <!-- Hero -->
    <section class="dark-mode hero bg-size-cover bg-repeat-0 bg-position-center position-relative overflow-hidden pb-5 " style="min-height: 100vh;">
        <div class="container position-relative zindex-2 pb-md-2 pb-lg-4  hero-container ">

            <!-- Title -->
            <div class="row d-flex justify-content-center text-center pb-4 mb-2 zindex-5">
                <div class="col">
                    <h2 class="display-2 mb-4 text-warning">All Leagues</h2>
                </div>
            </div>

            <?php if(Auth::check()): ?>
            <span class="badge bg-warning px-3 rounded-pill">Ongoing</span>


            <!-- Icon boxes (Features) -->
            <div class="row row-cols-1 row-cols-md-3 g-4 pt-2 pt-md-4 pb-lg-2">

                <div class="col">
                    <!-- Pagination: Bullets -->
                    <div class="swiper swiper-nav-onhover"
                        data-swiper-options='{
                            "spaceBetween": 20,
                            "loop": true,
                            "effect": "fade",
                            "pagination": {
                            "el": ".swiper-pagination",
                            "clickable": true
                            },
                            "navigation": {
                            "prevEl": ".btn-prev",
                            "nextEl": ".btn-next"
                            },
                            "autoplay": {
                            "delay": 3000,
                            "disableOnInteraction": false
                            }
                        }'>
                        <?php $__currentLoopData = $allGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-wrapper">
                                
                                <?php $__currentLoopData = $league['games']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    

                                    <?php if($game->status == 1): ?>
                                        <!-- League Item -->
                                        <div class="swiper-slide">
                                            <!-- Button in the top right corner -->

                                            <h3 class="h5 text-uppercase mb-2 mt-n4 mt-sm-0 mt-md-n4 mt-xxl-0 text-warning text-center">
                                                <?php echo e($league['league_name']); ?>

                                            </h3>
                            
                                            <div class="card pt-1 pb-3 flex-column flex-sm-row flex-md-column flex-xxl-row align-items-center border-warning bg-black h-100">
                                            
                                            <?php if((Auth::check()) && (Auth::user()->role == 1)): ?>
                                                <a href="league/1/edit" class="btn position-absolute top-0 end-0 m-2 px-2 btn-link text-warning zindex-5">
                                                    <i class='bx bx-cog'></i>
                                                </a>
                                            <?php endif; ?>
                                                
                                                <!-- Display item details here using $item properties -->
                                                <img src="<?php echo e(url('assets/img/league/tournaments/MPL-Malaysia.png')); ?> " width="168" alt="Doctor icon" class="p-3 pe-0">
                                                <div class="card-body text-center text-sm-start text-md-center text-xxl-start pb-3 pb-sm-2 pb-md-3 pb-xxl-2">
                                                    <h3 class="h6 text-uppercase mb-2 mt-n4 mt-sm-0 mt-md-n4 mt-xxl-0 text-warning">
                                                        <?php echo e($game->name); ?>

                                                    </h3>
                                                    <p class="fs-sm mb-1"><?php echo e($league['description']); ?></p>
                                                    <a href="/league/<?php echo e($game->id); ?>" class="btn btn-link text-warning px-0">
                                                        Join Now
                                                        <i class='bx bxs-chevron-right-circle fs-xl ms-1'></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                    <?php else: ?>
                                        <div class="swiper-slide">
                                            <h3 class="h5 text-uppercase mb-2 mt-n4 mt-sm-0 mt-md-n4 mt-xxl-0 text-warning text-center">
                                                <?php echo e($league['league_name']); ?>

                                            </h3>
                                            <div class="league">
                                                <div class="card pt-1 pb-3 flex-column flex-sm-row flex-md-column flex-xxl-row align-items-center border-warning h-100"
                                                    style="background-color: rgba(0, 0, 0, 0.597);">
                                                    <?php if((Auth::check()) && (Auth::user()->role == 1)): ?>
                                                        <a href="league/1/edit" class="btn position-absolute top-0 end-0 m-2 px-2 btn-link text-warning zindex-5">
                                                            <i class='bx bx-cog'></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <img src="<?php echo e(url('assets/img/league/tournaments/MPL-Malaysia.png')); ?>" width="168"
                                                        alt="Doctor icon" class="p-3 pe-0">
                                                    <div
                                                        class="card-body text-center text-sm-start text-md-center text-xxl-start pb-3 pb-sm-2 pb-md-3 pb-xxl-2">
                                                        <h6 class="text-uppercase mb-2 mt-n4 mt-sm-0 mt-md-n4 mt-xxl-0 text-warning">
                                                            <?php echo e($game->name); ?>

                                                        </h6>
                                                        <p class="fs-sm mb-1"> <?php echo e($league['description']); ?></p>
                                                        <a class="btn btn-link text-warning px-0" aria-disabled="true">
                                                            Join Now
                                                            <i class="bx bx-right-arrow-alt fs-xl ms-1"></i>
                                                        </a>
                                                    </div>
                            
                                                    <!-- Overlay with text and background -->
                                                    <div class="overlay zindex-2">
                                                        <h3 class="fw-bold text-warning"><b>Registration closed</b></h3>
                                                    </div>
                            
                                                </div>
                                            </div>
            
                                        </div>
                                    <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        
                        

                        <!-- Pagination -->
                        <div class="swiper-pagination"></div>
                    </div>
                </div>

            </div>
                
            <?php else: ?>
                <p class="text-warning">Please login first !</p>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\mlbb\resources\views/league/main-league.blade.php ENDPATH**/ ?>