<?php $__env->startSection('content'); ?>
<!-- Hero image -->
<div class="jarallax d-none d-md-block" data-jarallax data-speed="0.35" style="position: relative;">
    <span class="position-absolute top-0 start-0 w-100 h-100 "></span>
    <div class="jarallax-img"
        style="background-image: url('<?php echo e(asset('assets/img/league/header-wildcard.png')); ?>'); background-size: cover;">
    </div>
    <div class="d-none d-xxl-block" style="height: 500px;"></div>
    <div class="d-none d-md-block d-xxl-none" style="height: 550px;"></div>
</div>

<!-- Hero -->
<section
    class="dark-mode bg-dark hero bg-size-cover bg-repeat-0 bg-position-center position-relative overflow-hidden pb-5 ">
    <div class="container position-relative zindex-2 pb-md-2 pb-lg-4  hero-container ">

        <!-- Title -->
        <div class="row d-flex justify-content-center text-center pb-4 mb-2 zindex-5">
            <div class="col">
                <h2 class="display-5 mb-4 text-warning">M5 Tournament Championship</h2>
            </div>
        </div>

        <!-- Icon boxes (Features) -->
        <div class="row row-cols-1 row-cols-md-3 g-4 pt-2 pt-md-4 pb-lg-2 d-flex justify-content-center">

            <div class="row g-3 card shadow w-75 py-4 px-5 overflow-auto" style="height:500px">

                <?php $count = 0 ?>
                
                <!-- Step 1: Rules and Regulations -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <div class="col mb-5">
                        <p class="h6 text-white" align="justify">
                            <?php echo e($game->brief_info); ?>

                        </p>
                        
                    </div>
                    <div class="col">
                        <!-- Vertical steps -->
                        <div class="steps  steps-sm text-white">

                            <!-- Step -->
                            <div class="step">
                                <div class="step-number">
                                    <div class="step-number-inner">1</div>
                                </div>
                                <div class="step-body">
                                    <h5 class="mb-2">Instructions for participation in the game:</h5>
                                    <p class="fs-sm mb-0">
                                        <ol>
                                            <?php
                                                $instructions = explode('// ', $game->instructions); // Replace $yourDynamicData with the variable holding your dynamic data
                                            ?>

                                            <?php $__currentLoopData = $instructions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($item) !== ''): ?>
                                                    <li><?php echo e(trim($item)); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ol>
                                    </p>
                                </div>
                            </div>

                            <!-- Step -->
                            <div class="step">
                                <div class="step-number">
                                    <div class="step-number-inner">2</div>
                                </div>
                                <div class="step-body">
                                    <h5 class="mb-2">Player Limits</h5>
                                    <p class="fs-sm mb-0">
                                        <ul>
                                            <?php
                                                $player_rules = explode('// ', $game->player_rule); // Replace $yourDynamicData with the variable holding your dynamic data
                                            ?>

                                            <?php $__currentLoopData = $player_rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($item) !== ''): ?>
                                                    <li><?php echo e(trim($item)); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </p>
                                </div>
                            </div>

                            <!-- Step -->
                            <div class="step">
                                <div class="step-number">
                                    <div class="step-number-inner">3</div>
                                </div>
                                <div class="step-body">
                                    <h5 class="mb-2">Reserve Rules</h5>
                                    <p class="fs-sm mb-0">
                                        <ul>
                                            <?php
                                                $reserve_rules = explode('// ', $game->reserve_rule); // Replace $yourDynamicData with the variable holding your dynamic data
                                            ?>

                                            <?php $__currentLoopData = $reserve_rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($item) !== ''): ?>
                                                    <li><?php echo e(trim($item)); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </p>
                                </div>
                            </div>

                            <!-- Step -->
                            <div class="step">
                                <div class="step-number">
                                    <div class="step-number-inner">4</div>
                                </div>
                                <div class="step-body">
                                    <h5 class="mb-2">Transfer Window</h5>
                                    <p class="fs-sm mb-0">
                                        <ul>
                                            <?php
                                                $transfer_rules = explode('// ', $game->transfer_rule); // Replace $yourDynamicData with the variable holding your dynamic data
                                            ?>

                                            <?php $__currentLoopData = $transfer_rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($item) !== ''): ?>
                                                    <li><?php echo e(trim($item)); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>
                                    </p>
                                </div>
                            </div>

                            <!-- Step -->
                            <div class="step">
                                <div class="step-number">
                                    <div class="step-number-inner">5</div>
                                </div>
                                <div class="step-body">
                                    <h5 class="mb-2">Scoring</h5>
                                    <p class="fs-sm mb-0">
                                        <ul>
                                            <?php
                                                $scoring = explode('// ', $game->scoring); // Replace $yourDynamicData with the variable holding your dynamic data
                                            ?>

                                            <?php $__currentLoopData = $scoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($item) !== ''): ?>
                                                    <li><?php echo e(trim($item)); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </p>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col d-flex justify-content-end">
                        <button type="button" class="btn btn-warning" onclick="nextStep(<?php echo e($count); ?>)">Next</button>
                    </div>
                </div>

                <!-- Step 2: Hero Selection -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <div class="col">
                        <p class="h4 text-center text-uppercase text-white" align="justify">
                            - Select Your Hero -
                        </p>
                    </div>
                    <div class="col-12 mb-5 mb-lg-3">
                        <form action="<?php echo e(route('player.update', ['player' => 0])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <?php
                                    $roles = [
                                        'EXP Laner',
                                        'Jungler',
                                        'Mid Laner',
                                        'Gold Laner',
                                        'Roamer',
                                    ];
                                ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleKey => $roleValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="card card-hover" style="height: 300px; width: 150px">
                                            <div class="card-body d-grid align-items-center justify-content-center">
                                                <input name="playerName<?php echo e($roleKey); ?>" class="btn btn-link text-warning stretched-link openModalButton" data-index="<?php echo e($roleKey); ?>"  value="<?php echo e(session('playerName_' . $roleKey, '+')); ?>">
                                                <input type="hidden" name="playerID<?php echo e($roleKey); ?>" id="playerID" value="">
                                                <input type="hidden" name="teamID<?php echo e($roleKey); ?>" id="teamID" value="">
                                            </div>
                                            <div class="card-footer text-white text-center">
                                                <?php echo e($roleValue); ?> <?php echo e($roleKey); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div id="customModal" class="modal">
                                        <div class="modal-content">
                                            <span class="close" id="closeModal">&times;</span>
                                            <p>-Please Select Your Player-</p>
                                            
                                            <select name="player" id="playerSelect" class="form-select">
                                                <option value="0" disabled selected> - Choose Player -</option>
                                                    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($player->id); ?>" data-id="<?php echo e($player->id); ?>"  data-role="<?php echo e($player->role); ?>" data-nationality="<?php echo e($player->nationality); ?>" data-team="<?php echo e($player->team); ?>"><?php echo e($player->name); ?> (<?php echo e($roles[$player->role]); ?>) -- <em><?php echo e($player->team_name); ?></em></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button type="button" class="btn btn-sm btn-warning" id="choosePlayerButton">Choose Player</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="d-flex justify-content-center mt-3">

                                <!-- Add a hidden input field to store the current step index -->
                                
                                <button id="submitBtn" type="submit" class="btn btn-danger btn-sm rounded-pill px-5" >Confirm Players</button>
                            </div>
                        </form>
                        

                        
                        
                    </div>

                    
                    <div class="col d-flex justify-content-between mt-5 pb-3 py-2">
                        <button type="button" class="btn btn-warning" onclick="prevStep(<?php echo e($count); ?>)">Back</button>
                        <button type="button" class="btn btn-warning " onclick="nextStep(<?php echo e($count); ?>)">Next</button>
                    </div>
                </div>

                <!-- Step 3: Confirm heroes -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <form id="playerForm" action="<?php echo e(route('team.store', ['player' => 0])); ?>" method="post">
                        
                        <div class="col">
                            <p class="h4 text-center text-uppercase text-white" align="justify">
                                - Select Your Hero -
                            </p>
                        </div>
                        <div class="col-12 mb-5 mb-lg-3">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <?php
                                        $roles = [
                                            'EXP Laner',
                                            'Jungler',
                                            'Mid Laner',
                                            'Gold Laner',
                                            'Roamer',
                                        ];
                                    ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleKey => $roleValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col">

                                            <div class="card bg-gradient" style="height: 300px; width: 150px">
                                                <div class="card-body d-flex align-items-center justify-content-center">
                                                    
                                                    <input readonly name="playerName<?php echo e($roleKey); ?>" class="btn btn-link text-warning stretched-link openModalButton" value="<?php echo e(session('playerName_' . $roleKey, '+')); ?>">
                                                    <input type="hidden" name="playerID<?php echo e($roleKey); ?>" class="btn btn-link text-warning stretched-link" value="<?php echo e(session('playerID_' . $roleKey)); ?>">
                                                </div>
                                                <div class="card-footer text-white text-center">
                                                    <?php echo e($roleValue); ?>

                                                    
                                                </div>
                                            </div>
                                            
                                            <div class="text-start border-top border-1 mt-3">
                                                <label>
                                                    <input type="radio" name="captain" value="<?php echo e($roleKey); ?>" required onclick="checkSelection()"> Captain
                                                </label>
                                                <label>
                                                    <input type="radio" name="vice_captain" value="<?php echo e($roleKey); ?>" required onclick="checkSelection()"> Vice-Captain
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="d-flex justify-content-center">

                                    <!-- Add a hidden input field to store the current step index -->
                                    
                                </div>
                            
                            

                            <?php if(Session::has('playerName_0')): ?>
                                <script>
                                    alert(session(''))
                                </script>
                            <?php endif; ?>
                            
                        </div>
                        <div class="col d-flex justify-content-between mt-5 pb-3 py-2">
                            <button type="button" class="btn btn-warning" onclick="prevStep(<?php echo e($count); ?>)">Back</button>
                            <button type="button" class="btn btn-warning disabled" id="confirmHero-btn" onclick="nextStep(<?php echo e($count); ?>)">Next</button>
                        </div>
                    </form>
                </div>

                <?php if($game->reserve_isOn): ?>
                <!-- Step 4: Reserve Selection -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <div class="col">
                        <p class="h4 text-center text-uppercase text-white" align="justify">
                            - Select Your Reserve -
                        </p>
                    </div>
                    <div class="col-12 mb-5 mb-lg-3">
                        <form action="<?php echo e(route('player.update', ['player' => 1])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <?php
                                    $reserveRoles = [
                                        'EXP Laner',
                                        'Jungler',
                                        'Mid Laner',
                                        'Gold Laner',
                                        'Roamer',
                                    ];
                                ?>
                                <?php $__currentLoopData = $reserveRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserveKey => $reserveValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col">
                                        <div class="card card-hover" style="height: 300px; width: 150px">
                                            <div class="card-body d-grid align-items-center justify-content-center">
                                                <input name="reserveName<?php echo e($reserveKey); ?>" class="btn btn-link text-warning stretched-link openReserveModalButton" data-index="<?php echo e($reserveKey); ?>"  value="<?php echo e(session('reserveName_' . $reserveKey, '+')); ?>">
                                                <input type="hidden" name="reserveID<?php echo e($reserveKey); ?>" id="reserveID<?php echo e($reserveKey); ?>">
                                            </div>
                                            <div class="card-footer text-white text-center">
                                                <?php echo e($reserveValue); ?> <?php echo e($reserveKey); ?>

                                            </div>
                                        </div>
                                    </div>

                                    <div id="customReserveModal<?php echo e($reserveKey); ?>" class="modal">
                                        <div class="modal-content">
                                            <span class="close" id="closeReserveModal<?php echo e($reserveKey); ?>">&times;</span>
                                            <p>-Please Select Your Reserve-</p>
                                            
                                            <select name="reserve" id="reserveSelect<?php echo e($reserveKey); ?>" class="form-select">
                                                <option value="0" disabled selected> - Choose Reserve -</option>
                                                    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($reserve->id); ?>" data-role="<?php echo e($reserve->role); ?>" data-nationality="<?php echo e($reserve->nationality); ?>" data-team="<?php echo e($reserve->team); ?>"><?php echo e($reserve->name); ?> (<?php echo e($reserveRoles[$reserve->role]); ?>) -- <em><?php echo e($reserve->team_name); ?></em></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button type="button" class="btn btn-sm btn-warning" id="chooseReserveButton<?php echo e($reserveKey); ?>">Choose Reserve</button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="d-flex justify-content-center mt-3">
                                <button id="submitReserveBtn" type="submit" class="btn btn-danger btn-sm rounded-pill px-5" >Confirm Reserves</button>
                            </div>
                        </form>
                    </div>

                    <div class="col d-flex justify-content-between mt-5 pb-3 py-2">
                        <button type="button" class="btn btn-warning" onclick="prevStep(<?php echo e($count); ?>)">Back</button>
                        <button type="button" class="btn btn-warning " onclick="nextStep(<?php echo e($count); ?>)">Next</button>

                    </div>
                </div>
                <?php endif; ?>
                

                <!-- Step 5: Form Submission -->
                <div class="step-box" id="step<?php echo e(++$count); ?>">
                    <form action="<?php echo e(route('team.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="col">
                            <p class="h4 text-center text-uppercase text-white" align="justify">
                                - Confirm Your Players -
                            </p>
                        </div>
                        <div class="col-12 mb-5 mb-lg-3">
                            <div class="table-responsive">
                                <table class="table table-dark table-bordered">
                                    <thead>
                                        <tr>
                                        <th scope="col">#PlayerID</th>
                                        <th scope="col">Roles</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Team</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                            <?php for($i = 0; $i < 5; ++$i): ?>
                                                <tr>
                                                    <th scope="row"><?php echo e(Session::get('playerID_'.$i)); ?></th>
                                                    <td><input type="text" readonly class="form-control" name="roles[]" value="<?php echo e($roles[$i]); ?>" /></td>
                                                    <td><input type="text" readonly class="form-control" name="playerIDs[]" value="<?php echo e(Session::get('playerID_'.$i)); ?>" /></td>
                                                    <td>
                                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($player->id == Session::get('playerID_'.$i)): ?>
                                                                <input type="text" name="teamNames[]" value="<?php echo e($player->team_name); ?>" class="form-control" readonly/>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                </tr>
                                            <?php endfor; ?>
                                            
                                            <?php if($game->reserve_isOn): ?>
                                                <?php $rsvcnt= 0;?>
                                                <?php for($i = 0; $i < 5; ++$i): ?>
                                                    <?php if(Session::get('reserveName_'.$i) != '+'): ?>
                                                        <tr>
                                                            <th scope="row"><?php echo e(Session::get('reserveID_'.$i)); ?></th>
                                                            <td><input type="text" readonly class="form-control" name="reserves[]" value="Reserve_<?php echo e(++$rsvcnt); ?>" /></td>
                                                            <td><input type="text" readonly class="form-control" name="reserveIDs[]" value="<?php echo e(Session::get('reserveID_'.$i)); ?>" /></td>
                                                            <td>
                                                                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($player->id == Session::get('reserveID_'.$i)): ?>
                                                                        <input type="text" class="form-control" readonly name="reserveTeamNames[]" value="<?php echo e($player->team_name); ?>" />
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            <?php endif; ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col d-flex justify-content-between mt-5 pb-3 py-2">
                            <button type="button" class="btn btn-warning" onclick="prevStep(<?php echo e($count); ?>)">Back</button>
                            <button type="submit" class="btn btn-success ">Register</button>
    
                        </div>

                    </form>
                    
                    
                </div>


                
                
            </div>

        </div>
    </div>
</section>
<script>


    let currentStep = 1;
    
    console.log(currentStep);
    showStep(currentStep);


    function showStep(step) {
        const steps = document.querySelectorAll('.step-box');
        for (let i = 0; i < steps.length; i++) {
            steps[i].style.display = 'none';
        }
        steps[step - 1].style.display = 'block';
    }

    function nextStep(step) {
        currentStep = step + 1;
        showStep(currentStep);
    }

    function prevStep(step) {
        currentStep = step - 1;
        showStep(currentStep);
    }

    var selectedPlayers = 0;
    var reserveLimit = <?php echo e($game->reserve_limit); ?>;

    function checkSelection() {
        var captainSelected = document.querySelector('input[name="captain"]:checked');
        var viceCaptainSelected = document.querySelector('input[name="vice_captain"]:checked');
        var nextButton = document.getElementById('confirmHero-btn');

        if (captainSelected && viceCaptainSelected) {
            nextButton.classList.remove('disabled');
        } else {
            nextButton.classList.add('disabled');
        }
    }

</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
    // Your existing code...

    let selectedReserves = 0;

    // Add event listeners for modal buttons
    const openReserveButtons = document.querySelectorAll('.openReserveModalButton');
    openReserveButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const index = button.getAttribute('data-index');
            const modal = document.getElementById('customReserveModal' + index);
            modal.style.display = 'block';
        });
    });

    // Add event listeners for close buttons in modals
    const closeReserveButtons = document.querySelectorAll('.close');
    closeReserveButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const modal = button.parentElement;
            modal.style.display = 'none';
        });
    });

    // Add event listeners for chooseReserveButton
    const chooseReserveButtons = document.querySelectorAll('.btn-warning[id^="chooseReserveButton"]');
    chooseReserveButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            if (selectedReserves <= 2) {
                const index = button.getAttribute('id').replace('chooseReserveButton', '');
                const select = document.getElementById('reserveSelect' + index);
                const selectedOption = select.options[select.selectedIndex];
                const reserveIDInput = document.getElementById('reserveID' + index);

                // Update the value of the linked input in the main form
                const linkedInput = document.querySelector('input[name="reserveName' + index + '"]');
                linkedInput.value = selectedOption.text.split(' (')[0];
                reserveIDInput.value = selectedOption.value;


                // You might want to update other hidden fields as well (e.g., reserveID)

                // Close the modal
                const modal = document.getElementById('customReserveModal' + index);
                modal.style.display = 'none';

                // Disable the selected option in the dropdown
                selectedOption.disabled = true;

                // Increment the count of selected reserves
                selectedReserves++;
            }
        });
    });

    // Add event listener to close modals if clicked outside the modal content
    window.addEventListener('click', function (event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(function (modal) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
});


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\mlbb\resources\views/league/join-league.blade.php ENDPATH**/ ?>